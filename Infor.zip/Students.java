import java.util.Scanner;
public class Students {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Infor st = new Infor();
		Scanner sc = new Scanner(System.in);
		
		st.setName("NgoHoaiLinh");
		st.setMahs("110124100");
		st.setAge(25);
		st.setSex(1);
		
		System.out.print("Ma HV: " + st.showMahs() + "\n");
		System.out.print("Ho ten: " + st.getName()+ "\n");
		System.out.print("Age: " + st.showAge() + "\n");
		int x = sc.nextInt();
		st.setAge(x);
		System.out.print("Age (Edited): " + st.showAge() + "\n");
		if(st.showSex()==1) System.out.print("Sex: Nam\n");
		else System.out.print("Sex: Nu\n");
		st.report();
		
	}

}
