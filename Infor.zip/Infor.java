
public class Infor {
	private String name;
	private int age, sex;
	private String Mahs;
	
	//Lay du lieu---getter
	public String getName() {
		return name;
	}
	public int showAge() {
		return age;
	}
	public int showSex() {
		return sex;
	}
	public String showMahs() {
		return Mahs;
	}
	public void report() {
		System.out.print("Chuong trinh code da ket thuc!!");
	}
	
	//Nhap du lieu ---Setter
	public void setName(String name) {
		this.name = name;
	}
	public void setAge (int age) {
		this.age = age;
	}
	public void setSex (int sex) {
		this.sex=sex;
	}
	public void setMahs (String m) {
		this.Mahs = m;
	}
}
