import java.util.Scanner;
public class BT1 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		//Input
		int a = sc.nextInt(), b = sc.nextInt();
		
		//GiaiThuat
		if(a>b) {
			System.out.print(a); //Output
		}
		else System.out.print(b); //Output

	}

}
