import java.util.Scanner;


public class Student {
	private String name;
	private int id;
	private int age;
	
	//a. cac get, set cho thuoc tinh
	public void set_name(String name){
		this.name = name;
	}
	public void set_id (int id){
		this.id = id;
	}
	public void set_age(int age){
		this.age = age;
	}
	
	public int get_id(){
		return id;
	}
	public String get_name(){
		return name;
	}
	public int get_age(){
		return age;
	}
	
	//b. Constructor Thiet lap gia tri thuoc tinh
	public Student (){
		
	}
	public Student(int id, String name, int age){
		this.id = id;
		this.name = name;
		this.age = age;
	}
	
	//c. Phuong thuc tra ve Studen vua nhap
	public Student get_SV(){
		Scanner sc = new Scanner(System.in);
		int id = sc.nextInt(),
			age = sc.nextInt();
		String name = sc.nextLine();
		Student s = new Student(id, name, age);
		return s;
	}

	//d. Phuong thuc in ra man hinh cac tham so cua Student
	public void GetInfo() {
		System.out.print(this.get_id() + " ");
		System.out.print(this.get_name() + " ");
		System.out.print(this.get_age() + "\n");
	}
	
}

