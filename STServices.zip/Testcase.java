import java.util.Scanner;


public class Testcase {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		STServices stsv = new STServices();
		
		//e. khai bao mang luu tru 5 sinh vien 
		Student [] arr = new Student[10];
		int n = sc.nextInt();
		
		for(int i=0; i<n; i++){
			int id, age;
			String name;
			id = sc.nextInt();
			age = sc.nextInt();
			name = sc.nextLine();
			arr[i] = new Student(id, name, age);
		}
		
		System.out.print("Thong tin sv: \n");
		for(int i=0; i<n; i++){
			arr[i].GetInfo();
		}
		
		//f. in ra man hinh nhung sv co id<10
		System.out.print("id < 10 \n");
		for(int i=0; i<n; i++){
			if(arr[i].get_id()<10){
				arr[i].GetInfo();
			}
		}
		//h.a
		Student st = new Student();
		stsv.printSV(st.get_SV());
		
		//h.b
		System.out.print("Sinh vien can tim: \n");
		int fid = sc.nextInt();
		stsv.find_st(arr, n, fid);
		
		//h.c
		System.out.print("So luong thong tin sinh vien: ");
		int sl = sc.nextInt();
		stsv.input_st(sl);
		
		sc.close();
	}

}
