import java.util.Scanner;


public class STServices {
	
	//h.a
	public void printSV(Student st){
		st.GetInfo();
	}
	
	//h.b
	public void find_st(Student a[], int n, int id){
		for(int i=0; i<n; i++){
			if(a[i].get_id() == id){
				a[i].GetInfo();
			}
		}
	}
	
	//h.c
	public void input_st(int n){
		Student [] arr = new Student[n];
		Scanner sc = new Scanner(System.in);
		for(int i=0; i<n; i++){
			int id, age;
			String name;
			id = sc.nextInt();
			age = sc.nextInt();
			name = sc.nextLine();
			arr[i] = new Student(id, name, age);
		}
		System.out.print("Thong tin sv: \n");
		for(int i=0; i<n; i++){
			arr[i].GetInfo();
		}
		
		sc.close();
	}
}
